<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Backoffice</title>
<style>
  body {
    font-family: 'Segoe UI', Arial, sans-serif;
    background: #f4f6f8;
    margin: 0;
    padding: 20px;
    color: #333;
  }

  h1, h2 {
    text-align: center;
    color: rgb(0, 162, 255);
    margin-bottom: 15px;
  }

  table {
    width: 90%;
    margin: 20px auto;
    border-collapse: collapse;
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
  }

  th {
    background: rgb(0, 162, 255);
    color: white;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    padding: 12px;
  }

  td {
    padding: 10px;
    border-bottom: 1px solid #eee;
    text-align: center;
  }

  tr:hover {
    background: #f0f9ff;
  }

  a {
    text-decoration: none;
    color: rgb(0, 162, 255);
    font-weight: 600;
  }

  a:hover {
    text-decoration: underline;
  }

  p {
    text-align: center;
    color: #777;
  }
</style>
</head>
<body>
<!-- tu contenido PHP/HTML -->
</body>
</html>

<?php
require 'db.php';

// --- Gestión de usuarios pendientes ---
if (isset($_GET['action'], $_GET['idUser'])) {
    $idUser = (int) $_GET['idUser'];
    if ($_GET['action'] === 'approve') {
        $pdo->prepare('UPDATE usuarios SET status="active" WHERE idUser=?')->execute([$idUser]);
    } elseif ($_GET['action'] === 'deny') {
        $pdo->prepare('UPDATE usuarios SET status="denied" WHERE idUser=?')->execute([$idUser]);
    }
}

$pending = $pdo->query("SELECT * FROM usuarios WHERE status='pending'")->fetchAll();
$horas = $pdo->query("
    SELECT w.*, u.nombre, u.idUser 
    FROM horastrabajo w 
    JOIN usuarios u ON u.idUser = w.user_id 
    ORDER BY w.created_at DESC
")->fetchAll();
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Backoffice</title>
</head>
<body>
  <h1>Usuarios pendientes</h1>
  <table border="1">
    <tr><th>Cédula</th><th>Nombre</th><th>Acciones</th></tr>
    <?php foreach($pending as $p): ?>
      <tr>
        <td><?= htmlspecialchars($p['idUser']) ?></td>
        <td><?= htmlspecialchars($p['nombre']) ?></td>
        <td>
          <a href="?action=approve&idUser=<?= $p['idUser'] ?>">Habilitar</a>
          <a href="?action=deny&idUser=<?= $p['idUser'] ?>">Denegar</a>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>

  <h1>Horas registradas</h1>
  <table border="1">
    <tr><th>Cédula</th><th>Nombre</th><th>Fecha</th><th>Horas</th><th>Descripción</th></tr>
    <?php foreach($horas as $h): ?>
      <tr>
        <td><?= htmlspecialchars($h['idUser']) ?></td>
        <td><?= htmlspecialchars($h['nombre']) ?></td>
        <td><?= htmlspecialchars($h['work_date']) ?></td>
        <td><?= htmlspecialchars($h['horas']) ?></td>
        <td><?= htmlspecialchars($h['descripcion']) ?></td>
      </tr>
    <?php endforeach; ?>
  </table>

  <h2>📁 Comprobantes subidos por los usuarios</h2>

<?php
try {
    $sql = "SELECT p.*, u.nombre, u.email 
            FROM pagos p
            JOIN usuarios u ON p.id_usuario = u.idUser
            ORDER BY p.fecha_subida DESC";
    $stmt = $pdo->query($sql);
    $pagos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($pagos) {
        echo "<table border='1' cellpadding='5' cellspacing='0' style='border-collapse:collapse; width:100%; text-align:center;'>";
        echo "<tr style='background-color:#ddd;'>
                <th>Usuario</th>
                <th>Email</th>
                <th>Tipo</th>
                <th>Archivo</th>
                <th>Estado</th>
                <th>Acción</th>
              </tr>";

        foreach ($pagos as $row) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['nombre']) . "</td>";
            echo "<td>" . htmlspecialchars($row['email']) . "</td>";
            echo "<td>" . ucfirst(htmlspecialchars($row['tipo'])) . "</td>";
            echo "<td><a href='" . htmlspecialchars($row['archivo']) . "' target='_blank'>Ver</a></td>";
            echo "<td>" . ucfirst(htmlspecialchars($row['estado'])) . "</td>";
            echo "<td>
                    <a href='validar_comprobante.php?id=" . $row['idPago'] . "&estado=aprobado'>✅ Aprobar</a> |
                    <a href='validar_comprobante.php?id=" . $row['idPago'] . "&estado=rechazado'>❌ Rechazar</a>
                  </td>";
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "<p>No hay comprobantes subidos aún.</p>";
    }

} catch (PDOException $e) {
    echo "<p>Error al obtener los comprobantes: " . htmlspecialchars($e->getMessage()) . "</p>";
}
?>

</body>
</html>
