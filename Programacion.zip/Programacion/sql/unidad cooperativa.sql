create table uniCoop (
idUniCoop int(5) not null,
BlockCoop int(5) not null,
finalidad varchar(100) not null,
constraint PK_IDUNICOOP primary key (idUniCoop)
);

