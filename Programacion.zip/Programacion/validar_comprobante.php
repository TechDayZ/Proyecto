<?php
require 'db.php';

if (isset($_GET['id'], $_GET['estado'])) {
    $idPago = (int) $_GET['id'];
    $estado = $_GET['estado'];

    if (!in_array($estado, ['aprobado', 'rechazado'])) {
        die("Estado no válido.");
    }

    try {
        $stmt = $pdo->prepare("UPDATE pagos SET estado = ? WHERE idPago = ?");
        $stmt->execute([$estado, $idPago]);
        echo "✅ Estado actualizado correctamente.";
        echo "<br><a href='backoffice.php'>Volver al panel</a>";
    } catch (PDOException $e) {
        echo "❌ Error al actualizar el estado: " . htmlspecialchars($e->getMessage());
    }
} else {
    echo "❌ Parámetros faltantes.";
}
?>
